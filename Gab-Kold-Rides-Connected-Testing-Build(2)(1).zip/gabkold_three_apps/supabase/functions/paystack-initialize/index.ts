import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const auth = req.headers.get('Authorization') || '';
    const userClient = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) return Response.json({ error: 'Sign in required' }, { status: 401, headers: cors });
    const { ride_id } = await req.json();
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: ride, error } = await admin.from('rides').select('*').eq('id', ride_id).eq('passenger_id', user.id).single();
    if (error || !ride || ride.payment_method !== 'card' || !ride.fare_estimate) return Response.json({ error: 'Card ride or fare not found' }, { status: 400, headers: cors });
    const reference = `GKR-${ride.id}-${crypto.randomUUID()}`;
    const amount_kobo = Math.round(Number(ride.fare_estimate) * 100);
    const pay = await fetch('https://api.paystack.co/transaction/initialize', { method: 'POST', headers: { Authorization: `Bearer ${Deno.env.get('PAYSTACK_SECRET_KEY')}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ email: user.email, amount: amount_kobo, currency: 'NGN', reference, callback_url: Deno.env.get('PAYSTACK_CALLBACK_URL'), metadata: { ride_id: ride.id, passenger_id: user.id } }) });
    const payload = await pay.json();
    if (!pay.ok || !payload.status) return Response.json({ error: payload.message || 'Paystack initialization failed' }, { status: 502, headers: cors });
    await admin.from('payment_transactions').insert({ ride_id: ride.id, passenger_id: user.id, reference, amount_kobo, checkout_url: payload.data.authorization_url, provider_response: payload.data, status: 'initialized' });
    return Response.json({ authorization_url: payload.data.authorization_url, reference }, { headers: cors });
  } catch (e) { return Response.json({ error: String(e) }, { status: 500, headers: cors }); }
});

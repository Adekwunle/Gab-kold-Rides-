import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
async function verifySignature(body: string, signature: string, secret: string) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-512' }, false, ['sign']);
  const mac = new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(body)));
  return [...mac].map(b => b.toString(16).padStart(2, '0')).join('') === signature;
}
Deno.serve(async (req) => {
  const raw = await req.text();
  const signature = req.headers.get('x-paystack-signature') || '';
  if (!await verifySignature(raw, signature, Deno.env.get('PAYSTACK_SECRET_KEY')!)) return new Response('Invalid signature', { status: 401 });
  const event = JSON.parse(raw);
  if (event.event === 'charge.success') {
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const reference = event.data.reference;
    const { data: txn } = await admin.from('payment_transactions').select('*').eq('reference', reference).single();
    if (txn && Number(event.data.amount) === Number(txn.amount_kobo) && event.data.currency === txn.currency) {
      await admin.from('payment_transactions').update({ status: 'success', provider_response: event.data, updated_at: new Date().toISOString() }).eq('reference', reference);
      await admin.from('rides').update({ payment_status: 'paid' }).eq('id', txn.ride_id).eq('passenger_id', txn.passenger_id);
    }
  }
  return new Response('ok', { status: 200 });
});

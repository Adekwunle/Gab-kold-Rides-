GAB-KOLD RIDES — LIVE BOOKING BACKEND PACKAGE
Three connected web apps: passenger, driver, admin.

PROJECT CONFIGURATION
The supplied Supabase Project URL and publishable key are already placed in config.js. The key is intended for browser use. Do not add a service_role or secret key to these files.

SETUP — REQUIRED BEFORE THE APPS CAN WORK
1. Open https://supabase.com/dashboard and select the project whose URL is https://ehwknygzxfffbxjufsvw.supabase.co.
2. Open SQL Editor > New query.
3. Open schema.sql from this package, copy the FULL contents into SQL Editor, and click Run.
4. Confirm the query completes successfully. If it reports an error, copy the complete error text and resolve it before using the apps. Do not paste a document-sharing URL into SQL Editor.
5. In Authentication > Providers, ensure Email is enabled. For initial testing, email confirmation can remain enabled; users must confirm their email before sign-in if Supabase requires it.
6. Register your own account using the Passenger app or Driver app, then sign out.
7. To make your own account the administrator, open SQL Editor and run the following after replacing the email with the exact email you registered:

update public.profiles
set role = 'admin'
where id = (select id from auth.users where email = 'YOUR_EMAIL_HERE');

8. Sign in to the Admin dashboard. Only this account should receive the admin role. Do not grant admin to drivers or passengers.
9. Host this folder on an HTTPS static host (for example, a static site host). Open passenger.html, driver.html and admin.html from the hosted site. A local file:// preview may be blocked by browser restrictions.

APP LINKS AFTER HOSTING
/passenger.html — passenger booking
/driver.html — driver registration, approval, online status, accepting and progressing trips
/admin.html — approve/reject drivers and monitor rides

WHAT IS CONNECTED IN THIS MVP
- Supabase email/password account creation and sign-in.
- Passenger profile and driver profile creation.
- Driver vehicle detail submission and admin approval.
- Driver online/offline status (approved drivers only).
- Passenger creates a ride request in the live database.
- Approved online drivers can see open requests and race-safe accept one ride.
- Driver can mark arrived, start trip and complete trip.
- Passenger can cancel a ride while it is still requested.
- Admin can approve/reject driver applications and monitor ride records.
- Ride changes are streamed to the dashboards using Supabase Realtime.
- Payment choice is recorded as cash, transfer or card.

IMPORTANT LIMITATIONS — NOT A FULL COMMERCIAL RELEASE
- This package is a browser-based MVP, not installable Android/iPhone APK/IPA apps.
- The backend is NOT live until you run schema.sql successfully and test sign-up/sign-in.
- No GPS/live map, geocoding, distance-based fare engine, automatic nearby-driver matching, push notifications, or emergency/SOS workflow yet. Drivers currently see open requests across the pilot market; location filtering is not implemented.
- No card gateway is integrated. Selecting card only records the intended method; it does not charge a card. Bank transfers are not automatically verified.
- No automated fare, 15% commission ledger, driver payout, refunds, or reconciliation yet. Do not rely on the placeholder fare field for charging customers.
- Driver identity, licence, insurance and vehicle documents are not uploaded/verified in this version. Do not collect sensitive documents through this MVP.
- Before public launch, add phone OTP, document verification, server-side fare/commission rules, payment provider integration, stronger operational controls, privacy/terms, and test all RLS and RPC permissions.

BUSINESS SETTINGS TO IMPLEMENT IN THE NEXT RELEASE
Ibadan launch coverage; cars only; cash/bank transfer/card (card after gateway integration); platform commission 15%; both open driver registration and invitation recruitment.

V2 UPGRADE
See UPGRADE_V2_README.txt and upgrade.sql for GPS, nearby dispatch, estimated fare, passenger tracking, commission ledger and Paystack Edge Function deployment. Run upgrade.sql only after the original schema.sql. Paystack card charging remains inactive until you deploy the Edge Functions and set your own Paystack secret in Supabase.

-- GAB-KOLD RIDES v2 upgrade. Run AFTER the original schema.sql.
-- Pricing is an initial transparent estimate, not a road-route quote.
create extension if not exists pgcrypto;
alter table public.rides
  add column if not exists pickup_lat double precision,
  add column if not exists pickup_lng double precision,
  add column if not exists destination_lat double precision,
  add column if not exists destination_lng double precision,
  add column if not exists estimated_distance_km numeric(8,2),
  add column if not exists fare_final numeric(12,2),
  add column if not exists payment_status text not null default 'unpaid';
create table if not exists public.driver_locations (
  driver_id uuid primary key references public.profiles(id) on delete cascade,
  latitude double precision not null,
  longitude double precision not null,
  accuracy_m double precision,
  heading double precision,
  speed_mps double precision,
  updated_at timestamptz not null default now()
);
create table if not exists public.commission_ledger (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null unique references public.rides(id),
  driver_id uuid not null references public.profiles(id),
  gross_fare numeric(12,2) not null,
  platform_commission numeric(12,2) not null,
  driver_earnings numeric(12,2) not null,
  commission_rate numeric(5,4) not null default 0.15,
  created_at timestamptz not null default now()
);
create table if not exists public.payment_transactions (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null references public.rides(id),
  passenger_id uuid not null references public.profiles(id),
  provider text not null default 'paystack',
  reference text unique not null,
  amount_kobo bigint not null,
  currency text not null default 'NGN',
  status text not null default 'initialized' check(status in ('initialized','success','failed','refunded')),
  checkout_url text,
  provider_response jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists driver_locations_updated_idx on public.driver_locations(updated_at desc);
create index if not exists commission_driver_created_idx on public.commission_ledger(driver_id,created_at desc);

create or replace function public.distance_km(a_lat double precision,a_lng double precision,b_lat double precision,b_lng double precision)
returns double precision language sql immutable as $$
 select 6371 * 2 * asin(sqrt(least(1.0,
  power(sin(radians(b_lat-a_lat)/2),2) + cos(radians(a_lat))*cos(radians(b_lat))*power(sin(radians(b_lng-a_lng)/2),2)
 ))) $$;

create or replace function public.update_driver_location(p_lat double precision,p_lng double precision,p_accuracy double precision default null,p_heading double precision default null,p_speed double precision default null)
returns void language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null then raise exception 'Sign in required'; end if;
 if p_lat not between -90 and 90 or p_lng not between -180 and 180 then raise exception 'Invalid GPS coordinates'; end if;
 if not exists(select 1 from public.driver_profiles where user_id=auth.uid() and approval_status='approved' and is_online=true) then raise exception 'Only approved online drivers can share location'; end if;
 insert into public.driver_locations(driver_id,latitude,longitude,accuracy_m,heading,speed_mps,updated_at)
 values(auth.uid(),p_lat,p_lng,p_accuracy,p_heading,p_speed,now())
 on conflict(driver_id) do update set latitude=excluded.latitude,longitude=excluded.longitude,accuracy_m=excluded.accuracy_m,heading=excluded.heading,speed_mps=excluded.speed_mps,updated_at=now();
end; $$;

create or replace function public.create_ride_with_gps(p_pickup text,p_destination text,p_payment_method text,p_pickup_lat double precision,p_pickup_lng double precision,p_dest_lat double precision,p_dest_lng double precision,p_note text default null)
returns public.rides language plpgsql security definer set search_path=public as $$
declare result public.rides; km numeric; amount numeric;
begin
 if auth.uid() is null or not exists(select 1 from public.profiles where id=auth.uid() and role='passenger') then raise exception 'Passenger sign-in required'; end if;
 if length(trim(coalesce(p_pickup,'')))<3 or length(trim(coalesce(p_destination,'')))<3 then raise exception 'Enter pickup and destination'; end if;
 if p_payment_method not in ('cash','transfer','card') then raise exception 'Invalid payment method'; end if;
 if p_pickup_lat not between 7.0 and 7.8 or p_dest_lat not between 7.0 and 7.8 or p_pickup_lng not between 3.5 and 4.2 or p_dest_lng not between 3.5 and 4.2 then raise exception 'Coordinates must be within the Ibadan pilot area'; end if;
 km := round((public.distance_km(p_pickup_lat,p_pickup_lng,p_dest_lat,p_dest_lng)*1.25)::numeric,2);
 amount := greatest(1000,round(800 + km*250));
 insert into public.rides(passenger_id,pickup,destination,payment_method,passenger_note,pickup_lat,pickup_lng,destination_lat,destination_lng,estimated_distance_km,fare_estimate,platform_commission,driver_earnings)
 values(auth.uid(),trim(p_pickup),trim(p_destination),p_payment_method,nullif(trim(coalesce(p_note,'')),''),p_pickup_lat,p_pickup_lng,p_dest_lat,p_dest_lng,km,amount,round(amount*0.15,2),round(amount*0.85,2)) returning * into result;
 return result;
end; $$;

-- Drivers receive only requests whose pickup is within 10km of their last GPS point (fresh within 2 minutes).
create or replace function public.get_nearby_ride_requests(p_radius_km double precision default 10)
returns table(id uuid,passenger_id uuid,pickup text,destination text,payment_method text,status text,fare_estimate numeric,estimated_distance_km numeric,requested_at timestamptz,distance_to_pickup_km double precision)
language plpgsql security definer set search_path=public as $$
declare lat double precision; lng double precision;
begin
 select l.latitude,l.longitude into lat,lng from public.driver_locations l join public.driver_profiles d on d.user_id=l.driver_id
 where l.driver_id=auth.uid() and d.approval_status='approved' and d.is_online=true and l.updated_at>now()-interval '2 minutes';
 if lat is null then raise exception 'Turn on availability and enable GPS to receive nearby requests'; end if;
 return query select r.id,r.passenger_id,r.pickup,r.destination,r.payment_method,r.status,r.fare_estimate,r.estimated_distance_km,r.requested_at,public.distance_km(lat,lng,r.pickup_lat,r.pickup_lng)
 from public.rides r where r.status='requested' and r.driver_id is null and r.pickup_lat is not null and public.distance_km(lat,lng,r.pickup_lat,r.pickup_lng)<=least(greatest(p_radius_km,1),20)
 order by public.distance_km(lat,lng,r.pickup_lat,r.pickup_lng) asc limit 30;
end; $$;

create or replace function public.accept_ride(p_ride_id uuid) returns public.rides language plpgsql security definer set search_path=public as $$
declare result public.rides; lat double precision; lng double precision;
begin
 if not exists(select 1 from public.driver_profiles where user_id=auth.uid() and approval_status='approved' and is_online=true) then raise exception 'You must be an approved online driver'; end if;
 select latitude,longitude into lat,lng from public.driver_locations where driver_id=auth.uid() and updated_at>now()-interval '2 minutes';
 if lat is null then raise exception 'Enable GPS before accepting a ride'; end if;
 update public.rides r set driver_id=auth.uid(),status='accepted',accepted_at=now(),updated_at=now()
 where r.id=p_ride_id and r.status='requested' and r.driver_id is null and public.distance_km(lat,lng,r.pickup_lat,r.pickup_lng)<=10 returning r.* into result;
 if result.id is null then raise exception 'Ride unavailable or outside your 10km dispatch radius'; end if;
 return result;
end; $$;

-- Record one 15% commission entry when a trip is completed. Idempotent by ride_id.
create or replace function public.write_commission_ledger() returns trigger language plpgsql security definer set search_path=public as $$
declare gross numeric;
begin
 if new.status='completed' and old.status is distinct from 'completed' and new.driver_id is not null then
  gross:=coalesce(new.fare_final,new.fare_estimate,0);
  if gross<=0 then raise exception 'Cannot complete a trip without a valid fare'; end if;
  new.platform_commission:=round(gross*0.15,2); new.driver_earnings:=gross-new.platform_commission;
  insert into public.commission_ledger(ride_id,driver_id,gross_fare,platform_commission,driver_earnings)
  values(new.id,new.driver_id,gross,new.platform_commission,new.driver_earnings) on conflict(ride_id) do nothing;
 end if;
 return new;
end; $$;
drop trigger if exists rides_commission_ledger on public.rides;
create trigger rides_commission_ledger before update of status on public.rides for each row execute function public.write_commission_ledger();

alter table public.driver_locations enable row level security;
alter table public.commission_ledger enable row level security;
alter table public.payment_transactions enable row level security;
drop policy if exists driver_location_read_own on public.driver_locations;
create policy driver_location_read_own on public.driver_locations for select to authenticated using(driver_id=auth.uid() or public.is_admin());
drop policy if exists ledger_driver_or_admin_read on public.commission_ledger;
create policy ledger_driver_or_admin_read on public.commission_ledger for select to authenticated using(driver_id=auth.uid() or public.is_admin());
drop policy if exists payment_own_or_admin_read on public.payment_transactions;
create policy payment_own_or_admin_read on public.payment_transactions for select to authenticated using(passenger_id=auth.uid() or public.is_admin());
grant select on public.driver_locations,public.commission_ledger,public.payment_transactions to authenticated;
grant execute on function public.update_driver_location(double precision,double precision,double precision,double precision,double precision) to authenticated;
grant execute on function public.create_ride_with_gps(text,text,text,double precision,double precision,double precision,double precision,text) to authenticated;
grant execute on function public.get_nearby_ride_requests(double precision) to authenticated;
grant execute on function public.distance_km(double precision,double precision,double precision,double precision) to authenticated;

-- Realtime location tracking. Ignore duplicate publication membership.
do $$ begin alter publication supabase_realtime add table public.driver_locations; exception when duplicate_object then null; when others then null; end $$;


create or replace function public.get_my_ride_driver_location(p_ride_id uuid)
returns table(latitude double precision,longitude double precision,updated_at timestamptz)
language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from public.rides where id=p_ride_id and passenger_id=auth.uid() and status in ('accepted','arrived','in_progress')) then raise exception 'No active ride access'; end if;
 return query select l.latitude,l.longitude,l.updated_at from public.rides r join public.driver_locations l on l.driver_id=r.driver_id where r.id=p_ride_id and l.updated_at>now()-interval '3 minutes';
end; $$;
grant execute on function public.get_my_ride_driver_location(uuid) to authenticated;

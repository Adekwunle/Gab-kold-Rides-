// Public client configuration only. Never place a Supabase service_role/secret key here.
window.GABKOLD_SUPABASE_URL = 'https://ehwknygzxfffbxjufsvw.supabase.co';
window.GABKOLD_SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_i8iAQwN_zoQz3DC-GcnRGg_jbGU1PiA';

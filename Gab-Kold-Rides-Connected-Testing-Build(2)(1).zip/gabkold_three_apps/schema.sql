-- GAB-KOLD RIDES: live booking MVP backend
-- Run this entire file once in Supabase Dashboard > SQL Editor.
-- Uses the public publishable key in the browser; NEVER expose service_role keys.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role text not null default 'passenger' check (role in ('passenger','driver','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.driver_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  vehicle_make text,
  vehicle_model text,
  vehicle_colour text,
  plate_number text,
  approval_status text not null default 'pending' check (approval_status in ('pending','approved','rejected','suspended')),
  is_online boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.rides (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id),
  driver_id uuid references public.profiles(id),
  pickup text not null,
  destination text not null,
  passenger_note text,
  payment_method text not null check (payment_method in ('cash','transfer','card')),
  status text not null default 'requested' check (status in ('requested','accepted','arrived','in_progress','completed','cancelled')),
  fare_estimate numeric(12,2),
  platform_commission numeric(12,2),
  driver_earnings numeric(12,2),
  requested_at timestamptz not null default now(),
  accepted_at timestamptz,
  completed_at timestamptz,
  updated_at timestamptz not null default now()
);
create index if not exists rides_status_requested_idx on public.rides(status, requested_at desc);
create index if not exists rides_passenger_idx on public.rides(passenger_id, requested_at desc);
create index if not exists rides_driver_idx on public.rides(driver_id, requested_at desc);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
declare r text;
begin
  r := coalesce(new.raw_user_meta_data->>'role','passenger');
  if r not in ('passenger','driver') then r := 'passenger'; end if;
  insert into public.profiles(id,full_name,phone,role)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),new.raw_user_meta_data->>'phone',r)
  on conflict(id) do update set full_name=excluded.full_name, phone=excluded.phone;
  if r='driver' then insert into public.driver_profiles(user_id) values(new.id) on conflict do nothing; end if;
  return new;
end; $$;
drop trigger if exists on_auth_user_created_gabkold on auth.users;
create trigger on_auth_user_created_gabkold after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'); $$;

create or replace function public.create_ride(p_pickup text,p_destination text,p_payment_method text,p_note text default null)
returns public.rides language plpgsql security definer set search_path=public as $$
declare result public.rides;
begin
 if auth.uid() is null then raise exception 'Sign in required'; end if;
 if not exists(select 1 from public.profiles where id=auth.uid() and role='passenger') then raise exception 'Passenger account required'; end if;
 if length(trim(coalesce(p_pickup,'')))<3 or length(trim(coalesce(p_destination,'')))<3 then raise exception 'Enter a valid pickup and destination'; end if;
 if p_payment_method not in ('cash','transfer','card') then raise exception 'Invalid payment method'; end if;
 insert into public.rides(passenger_id,pickup,destination,payment_method,passenger_note)
 values(auth.uid(),trim(p_pickup),trim(p_destination),p_payment_method,nullif(trim(coalesce(p_note,'')),'')) returning * into result;
 return result;
end; $$;

create or replace function public.submit_driver_vehicle(p_make text,p_model text,p_colour text,p_plate text) returns void language plpgsql security definer set search_path=public as $$
begin
 update public.driver_profiles set vehicle_make=nullif(trim(p_make),''),vehicle_model=nullif(trim(p_model),''),vehicle_colour=nullif(trim(p_colour),''),plate_number=nullif(trim(p_plate),'') where user_id=auth.uid();
 if not found then raise exception 'Driver profile not found'; end if;
end; $$;

create or replace function public.set_driver_online(p_online boolean) returns void language plpgsql security definer set search_path=public as $$
begin
 update public.driver_profiles set is_online=p_online where user_id=auth.uid() and approval_status='approved';
 if not found then raise exception 'Driver account is not approved'; end if;
end; $$;

create or replace function public.accept_ride(p_ride_id uuid) returns public.rides language plpgsql security definer set search_path=public as $$
declare result public.rides;
begin
 if not exists(select 1 from public.driver_profiles where user_id=auth.uid() and approval_status='approved' and is_online=true) then raise exception 'You must be an approved online driver'; end if;
 update public.rides set driver_id=auth.uid(),status='accepted',accepted_at=now(),updated_at=now()
 where id=p_ride_id and status='requested' and driver_id is null returning * into result;
 if result.id is null then raise exception 'This ride is no longer available'; end if;
 return result;
end; $$;

create or replace function public.update_ride_status(p_ride_id uuid,p_status text) returns public.rides language plpgsql security definer set search_path=public as $$
declare result public.rides;
begin
 if p_status not in ('arrived','in_progress','completed','cancelled') then raise exception 'Invalid status change'; end if;
 update public.rides set status=p_status,updated_at=now(),completed_at=case when p_status='completed' then now() else completed_at end
 where id=p_ride_id and driver_id=auth.uid() and (
   (status='accepted' and p_status in ('arrived','cancelled')) or
   (status='arrived' and p_status in ('in_progress','cancelled')) or
   (status='in_progress' and p_status='completed')
 ) returning * into result;
 if result.id is null then raise exception 'Ride status cannot be changed'; end if;
 return result;
end; $$;

create or replace function public.cancel_own_ride(p_ride_id uuid) returns public.rides language plpgsql security definer set search_path=public as $$
declare result public.rides;
begin
 update public.rides set status='cancelled',updated_at=now() where id=p_ride_id and passenger_id=auth.uid() and status='requested' returning * into result;
 if result.id is null then raise exception 'Only a requested ride can be cancelled by its passenger'; end if;
 return result;
end; $$;

create or replace function public.admin_review_driver(p_driver_id uuid,p_decision text) returns void language plpgsql security definer set search_path=public as $$
begin
 if not public.is_admin() then raise exception 'Admin access required'; end if;
 if p_decision not in ('approved','rejected','suspended') then raise exception 'Invalid decision'; end if;
 update public.driver_profiles set approval_status=p_decision,is_online=false where user_id=p_driver_id;
end; $$;

alter table public.profiles enable row level security;
alter table public.driver_profiles enable row level security;
alter table public.rides enable row level security;

drop policy if exists profiles_read_self_or_admin on public.profiles;
create policy profiles_read_self_or_admin on public.profiles for select to authenticated using (id=auth.uid() or public.is_admin());
drop policy if exists drivers_read_self_admin on public.driver_profiles;
create policy drivers_read_self_admin on public.driver_profiles for select to authenticated using (user_id=auth.uid() or public.is_admin());
drop policy if exists drivers_admin_update on public.driver_profiles;
create policy drivers_admin_update on public.driver_profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists rides_read_related_or_available on public.rides;
create policy rides_read_related_or_available on public.rides for select to authenticated using (
 passenger_id=auth.uid() or driver_id=auth.uid() or public.is_admin() or
 (status='requested' and exists(select 1 from public.driver_profiles d where d.user_id=auth.uid() and d.approval_status='approved' and d.is_online=true))
);
-- No direct client INSERT/UPDATE/DELETE policies on rides. Mutations go through checked RPC functions.

grant usage on schema public to authenticated;
grant select on public.profiles,public.driver_profiles,public.rides to authenticated;
grant execute on function public.create_ride(text,text,text,text) to authenticated;
grant execute on function public.submit_driver_vehicle(text,text,text,text) to authenticated;
grant execute on function public.set_driver_online(boolean) to authenticated;
grant execute on function public.accept_ride(uuid) to authenticated;
grant execute on function public.update_ride_status(uuid,text) to authenticated;
grant execute on function public.cancel_own_ride(uuid) to authenticated;
grant execute on function public.admin_review_driver(uuid,text) to authenticated;
grant execute on function public.is_admin() to authenticated;

-- Enable realtime updates for booking/dispatch screens.
do $$ begin alter publication supabase_realtime add table public.rides; exception when duplicate_object then null; when others then null; end $$;

const { createClient } = supabase;
const db = createClient(window.GABKOLD_SUPABASE_URL, window.GABKOLD_SUPABASE_PUBLISHABLE_KEY);
const $ = (id) => document.getElementById(id);
const money = (v) => v == null ? 'To be confirmed' : new Intl.NumberFormat('en-NG',{style:'currency',currency:'NGN',maximumFractionDigits:0}).format(v);
const esc = (s='') => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function currentProfile(){ const {data:{user}}=await db.auth.getUser(); if(!user) return null; const {data,error}=await db.from('profiles').select('*').eq('id',user.id).single(); if(error) throw error; return {user,...data}; }
async function signOut(){await db.auth.signOut(); location.reload();}
function message(id,txt,bad=false){ const el=$(id); if(el){el.textContent=txt;el.className=bad?'error':'notice';} }
function showAuth(){ $('app').hidden=true; $('auth').hidden=false; }
function showApp(){ $('auth').hidden=true; $('app').hidden=false; }
async function loginOrRegister(mode,email,password,fullName,phone,role){
  if(mode==='register'){
    const {data,error}=await db.auth.signUp({email,password,options:{data:{full_name:fullName,phone,role}}});
    if(error) throw error;
    if(!data.session) return 'Account created. Check your email to confirm it, then sign in.';
    return 'Account created.';
  }
  const {error}=await db.auth.signInWithPassword({email,password}); if(error) throw error; return 'Signed in.';
}

GAB-KOLD RIDES — V2 GPS, DISPATCH, FARE & LEDGER UPGRADE

IMPORTANT: This is an incremental migration. The original schema.sql has already been run in your project. Run upgrade.sql ONCE in Supabase SQL Editor after that original schema. Do not rerun the original schema to apply this upgrade.

WHAT V2 ADDS
1. Passenger pickup GPS capture (browser asks permission after button tap).
2. Destination coordinate entry; the passenger can obtain coordinates from Google Maps by long-pressing/right-clicking the destination pin and copying the coordinates.
3. Server-side estimated distance and fare: straight-line distance x 1.25 road factor; ₦800 base + ₦250/km; ₦1,000 minimum. This is a preliminary estimate, not a turn-by-turn road-route quote. Set final commercial pricing only after road tests.
4. Driver GPS updates while approved and online. The browser must remain open and location permission enabled.
5. Nearby dispatch queue: approved online drivers with a GPS point updated within 2 minutes see unassigned requests within 10km, nearest first. Drivers still tap Accept; database race protection ensures only one driver gets the ride.
6. Passenger active-ride location refresh every 5 seconds through a permission-checked RPC.
7. 15% platform / 85% driver commission ledger entry when a trip is marked completed. A unique ride constraint prevents duplicate ledger entries.
8. Paystack Edge Function source for card checkout and webhook verification.

RUN THE DATABASE UPGRADE
- Supabase Dashboard > SQL Editor > New query.
- Paste all of upgrade.sql and Run.
- Confirm success. If an error occurs, stop and share the full error; do not disable RLS.

DEPLOY PAYSTACK EDGE FUNCTIONS (CARD CHARGING)
Card charging cannot work until you own/configure a Paystack account and add its keys to Supabase secrets. Do not put a Paystack secret key in config.js or any browser file.

From a computer with Supabase CLI installed, in the folder containing supabase/:
  supabase login
  supabase link --project-ref ehwknygzxfffbxjufsvw
  supabase secrets set PAYSTACK_SECRET_KEY=sk_test_REPLACE_ME PAYSTACK_CALLBACK_URL=https://YOUR-HOST/payment-return.html
  supabase functions deploy paystack-initialize
  supabase functions deploy paystack-webhook

The Supabase project URL and service-role key are supplied to deployed Edge Functions by Supabase environment. Never copy the service-role key into the client app. Configure your Paystack dashboard webhook URL to:
  https://ehwknygzxfffbxjufsvw.supabase.co/functions/v1/paystack-webhook
Use Paystack test keys and test cards first. Replace with live keys only after end-to-end testing and provider approval. The callback page is a separate hosted page you still need to publish; webhook confirmation, not the browser redirect, is the payment authority.

PAYMENT NOTES
- The card Edge Function initializes a Paystack checkout for the estimated fare after the ride request is created. Paystack secret key is server-side only.
- The webhook validates Paystack's HMAC signature and amount/currency before marking the payment transaction successful.
- This MVP charges the estimated fare at booking, not a post-trip metered final fare. Refund/adjustment and payout automation are not included.
- Cash and transfer are recorded as selected methods; transfer confirmation is manual. Never mark a transfer paid based only on a passenger screenshot.

LIMITATIONS / SAFETY BEFORE PUBLIC LAUNCH
- GPS and tracking require HTTPS and browser location permission. Driver tracking stops when browser/app is closed or background execution is suspended; this web MVP is not a native background GPS service.
- Destination coordinates are entered by the passenger; there is no address autocomplete or road-routing provider yet. Fare is approximate straight-line distance x 1.25.
- Matching is nearest-first within a 10km radius, but driver acceptance remains manual. No push notifications or timed offer escalation yet.
- No automatic driver payout, refunds, fraud checks, card preauthorisation, SOS or emergency dispatch.
- The SQL restricts coordinate bounds to an approximate Ibadan area; this is a rough bounding box, not an official service boundary.
- Validate RLS, account roles, pricing, provider webhooks, duplicate events, and real-device GPS with test accounts before public use. Get legal, insurance, privacy and Oyo State transport requirements checked.

APP CONFIG
The supplied Supabase URL and publishable key are already in config.js. Publish the complete folder over HTTPS; keep all JS, HTML, SQL and supabase/functions paths together.
